# Cleaned and analysis-ready data

Produced by `scripts/01_reference_preparation.py` from `data/raw/diabetic_data.xlsx`, applying the same rules as the
Power Query layer in the Power BI model. No rows removed: 101,766 encounters.

| File | Grain | Rows |
|---|---|---|
| fact_encounter_clean.csv | one hospital encounter | 101,766 |
| fact_encounter_medication.csv | encounter x prescribed diabetes medication | 120,054 |
| dim_admission_type.csv | admission type code | 8 |
| dim_discharge_disposition.csv | discharge disposition code | 30 |
| dim_admission_source.csv | admission source code | 25 |
| dim_age.csv | age band | 10 |
| dim_patient.csv | patient | 71,518 |

Readmission rates must use `eligible_for_readmission = 1` as the denominator (99,343 encounters).
Column definitions: `documentation/data_dictionary.md`. Cleaning decisions: `documentation/data_cleaning_log.md`.
